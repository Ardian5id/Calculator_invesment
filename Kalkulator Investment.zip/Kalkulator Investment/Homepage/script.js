document.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add('loaded'); 
});

function goToCalculator(calculatorType) {
    console.log(`Mengarahkan ke kalkulator: ${calculatorType}`);

    if (calculatorType === 'margin_used') {
        window.location.href = 'margin_calculator.html'; // PENTING: Arahkan ke file ini!
    } else {
        alert(`Kalkulator untuk ${calculatorType.replace('_', ' ').toUpperCase()} belum tersedia.`);
    }
}
