document.addEventListener('DOMContentLoaded', () => {
    // Memberikan nilai default saat halaman dimuat
    document.getElementById('symbols').value = 'XAUUSD';
    document.getElementById('balance').value = 1000;
    document.getElementById('openPrice').value = 3375;
    document.getElementById('slPrice').value = 3386;
    document.getElementById('tpPrice').value = 3360;
    document.getElementById('riskPercentage').value = 2;
    document.getElementById('leverage').value = 500; // Contoh default leverage

    // Event listener untuk saat halaman kembali di-load atau navigasi
    document.body.classList.add('loaded'); // Jika ingin efek fade-in juga di halaman ini
});


function calculateMargin() {
    const symbols = document.getElementById('symbols').value;
    const balance = parseFloat(document.getElementById('balance').value);
    const openPrice = parseFloat(document.getElementById('openPrice').value);
    const slPrice = parseFloat(document.getElementById('slPrice').value);
    const tpPrice = parseFloat(document.getElementById('tpPrice').value);
    const riskPercentage = parseFloat(document.getElementById('riskPercentage').value);
    const leverage = parseFloat(document.getElementById('leverage').value);

    // Validasi input dasar
    if (isNaN(balance) || isNaN(openPrice) || isNaN(slPrice) || isNaN(tpPrice) || isNaN(riskPercentage) || isNaN(leverage) || balance <= 0 || openPrice <= 0 || leverage <= 0) {
        alert("Mohon masukkan semua nilai dengan benar (angka positif).");
        return;
    }
    if (riskPercentage < 0.01 || riskPercentage > 100) {
        alert("Persentase risiko harus antara 0.01% dan 100%.");
        return;
    }
    if (openPrice === slPrice) {
        alert("Harga Open tidak boleh sama dengan Harga SL (Stop Loss).");
        return;
    }

    let pipsPerUnit = 0; // Nilai per pip per unit (misal: $10 untuk XAUUSD per lot standar)
    let contractSize = 0; // Ukuran kontrak per 1 lot standar
    let currencyPairValue = 1; // Untuk pair non-USD, misal EURUSD (value of 1 pip for 1 lot)
    let pairType = ''; // Untuk membedakan EURUSD vs XAUUSD
    let isBuy = true; // Akan ditentukan dari openPrice vs slPrice

    // Tentukan apakah posisi Buy atau Sell
    if (openPrice < slPrice) { // Jika Open Price < SL Price, berarti Buy
        isBuy = true;
    } else { // Jika Open Price > SL Price, berarti Sell
        isBuy = false;
    }

    // --- Konfigurasi Berdasarkan Simbol (Ini Sangat Penting!) ---
    // Nilai-nilai ini bisa bervariasi antar broker. Anda mungkin perlu menyesuaikannya.
    switch (symbols) {
        case 'XAUUSD':
            // XAUUSD (Gold) - Lot standar biasanya 100 unit atau 100 troy ounce.
            // Nilai pip/poin: 1 pip = $1 per 1 lot (jika harga bergerak 1.00 dari 1900.00 ke 1901.00)
            // Atau, jika 1 poin adalah 0.01, maka 1 pip = 0.01, dan 100 unit * 0.01 = $1 per 0.01 per lot.
            // Untuk XAUUSD, seringkali dihitung per poin (0.01). Jadi, jika SL 100 poin (1.00 dolar), maka $100 per lot.
            contractSize = 100; // 1 lot = 100 troy ounces
            pipsPerUnit = 0.01; // Tiap 0.01 (satu poin) adalah 1 pip
            pairType = 'commodity';
            break;
        case 'OIL': // Contoh Crude Oil, biasanya dihitung per barel
            contractSize = 1000; // 1 lot = 1000 barel (umumnya)
            pipsPerUnit = 0.01; // Tiap 0.01 (satu sen) adalah 1 pip
            pairType = 'commodity';
            break;
        case 'EURUSD':
        case 'GBPUSD':
            contractSize = 100000; // Lot standar 100,000 unit mata uang dasar
            pipsPerUnit = 0.0001; // Untuk 4 desimal
            pairType = 'forex_usd_quoted'; // Pair yang berakhir dengan USD
            break;
        case 'USDJPY':
            contractSize = 100000;
            pipsPerUnit = 0.01; // Untuk 2 desimal
            pairType = 'forex_jpy_quoted'; // Pair yang berakhir dengan JPY
            break;
        default:
            // Default untuk pair forex lainnya yang mungkin berakhir dengan USD
            contractSize = 100000;
            pipsPerUnit = 0.0001;
            pairType = 'forex_usd_quoted';
            break;
    }

    // --- Perhitungan SL Pips dan TP Pips ---
    let slPipsRaw = Math.abs(openPrice - slPrice);
    let tpPipsRaw = Math.abs(openPrice - tpPrice);

    let slPips, tpPips;

    // Untuk pair 4 desimal (EURUSD, GBPUSD), 1 pip = 0.0001
    // Untuk pair 2 desimal (USDJPY), 1 pip = 0.01
    // Untuk XAUUSD/OIL (komoditas), 1 poin (0.01) sering disebut 1 pip
    if (pairType === 'forex_usd_quoted') { // EURUSD, GBPUSD
        slPips = slPipsRaw / 0.0001;
        tpPips = tpPipsRaw / 0.0001;
    } else if (pairType === 'forex_jpy_quoted') { // USDJPY
        slPips = slPipsRaw / 0.01;
        tpPips = tpPipsRaw / 0.01;
    } else if (pairType === 'commodity') { // XAUUSD, OIL
        // Untuk komoditas, kita bisa definisikan pip sebagai pergerakan 0.01
        slPips = slPipsRaw / pipsPerUnit; // Ini akan menjadi jumlah 'poin' atau 'pip'
        tpPips = tpPipsRaw / pipsPerUnit;
    } else {
        // Fallback jika tidak dikenali, asumsikan 4 desimal atau sesuaikan
        slPips = slPipsRaw / 0.0001;
        tpPips = tpPipsRaw / 0.0001;
    }
    
    // Sesuaikan tanda SL Pips agar sesuai dengan gambar (-110)
    if (isBuy) { // Jika Buy, SL di bawah open, jadi SL Pips negatif
        slPips = -slPips;
    } else { // Jika Sell, SL di atas open, jadi SL Pips positif
        slPips = -slPips; // Karena di gambar SL Pips selalu negatif, ini untuk menyamakan tampilan
    }

    // Sesuaikan tanda TP Pips agar sesuai dengan gambar
    if (isBuy) { // Jika Buy, TP di atas open, jadi TP Pips positif
        tpPips = tpPips;
    } else { // Jika Sell, TP di bawah open, jadi TP Pips negatif
        tpPips = -tpPips;
    }

    // --- Perhitungan Risk Amount ---
    const riskAmount = (balance * riskPercentage) / 100;

    // --- Perhitungan Pip Value per Lot Standar ($ per pip untuk 1 Lot) ---
    // Ini adalah nilai 1 pip untuk 1 lot standar (contractSize)
    let pipValuePerLot = 0;
    if (pairType === 'forex_usd_quoted') {
        pipValuePerLot = contractSize * pipsPerUnit; // 100,000 * 0.0001 = $10 per pip
    } else if (pairType === 'forex_jpy_quoted') {
        // Untuk USDJPY, pip value = (Contract Size * Pip Step) / USDJPY Rate
        // Asumsi nilai JPY saat ini tidak signifikan mempengaruhi, atau kita bisa menggunakan Open Price
        pipValuePerLot = (contractSize * pipsPerUnit) / openPrice; // (100,000 * 0.01) / 150 = $6.66
    } else if (pairType === 'commodity') { // XAUUSD, OIL
        pipValuePerLot = contractSize * pipsPerUnit; // 100 * 0.01 = $1 per 'poin' untuk XAUUSD
                                                      // 1000 * 0.01 = $10 per 'poin' untuk OIL
    } else {
        pipValuePerLot = contractSize * pipsPerUnit; // Default
    }


    // --- Perhitungan Lot Size yang Disarankan ---
    // Banyak pip yang akan hilang jika SL tercapai
    let stopLossInPips = Math.abs(slPipsRaw / pipsPerUnit); // Selalu positif untuk perhitungan lot

    if (stopLossInPips === 0) {
        alert("Stop Loss Price tidak boleh sama dengan Open Price. Tidak dapat menghitung lot.");
        document.getElementById('noResults').style.display = 'block';
        document.getElementById('resultsBody').innerHTML = '';
        return;
    }
    
    // Formula umum Lot Size berdasarkan Risk
    // Lot = Risk Amount / (Stop Loss Pips * Pip Value per Pip per Lot)
    // Pip Value per Pip per Lot = (contractSize * pipsPerUnit * (pair is USD quoted ? 1 : CurrentPriceOfQuoteCurrencyInUSD))
    
    // Perhitungan nilai 1 pip (atau 1 poin untuk XAUUSD) untuk 1 unit (bukan 1 lot)
    let valuePerPointPerUnit = pipsPerUnit; // Misal 0.01 untuk XAUUSD (jika harga bergerak 0.01, itu 1 poin)
    if (pairType === 'forex_jpy_quoted') { // Misal USDJPY
        valuePerPointPerUnit = pipsPerUnit / openPrice; // Nilai 1 pip JPY ke USD
    } else if (pairType === 'forex_usd_quoted') { // Misal EURUSD
        valuePerPointPerUnit = pipsPerUnit; // Nilai 1 pip USD
    }

    // Nilai 1 poin per standar lot (100000 unit untuk forex, 100 untuk XAUUSD, 1000 untuk OIL)
    let valuePerPointPerStandardLot = contractSize * valuePerPointPerUnit;

    // Untuk XAUUSD/OIL, kita bisa menggunakan $1 per poin untuk 1 lot (100 unit XAUUSD)
    // Jika pergerakan 1.00 USD, itu 100 poin. Jadi, untuk 1 lot XAUUSD, 100 unit * 100 poin * 0.01 = $100.
    // Jika risk $100 dan SL 100 poin ($100 per lot), maka lot size = $100 / $100 = 1 lot.
    // Jika risk $20 dan SL 100 poin ($100 per lot), maka lot size = $20 / $100 = 0.2 lot.

    let recommendedLotSize = riskAmount / (stopLossInPips * valuePerPointPerStandardLot);
    
    // Lot size untuk XAUUSD dan OIL umumnya dalam 0.01 atau 0.1
    // Forex Lot size umumnya 0.01, 0.1, 1.0, dst.

    // Pembulatan Lot Size ke 2 desimal (micro lot)
    recommendedLotSize = Math.floor(recommendedLotSize * 100) / 100; // Pembulatan ke bawah agar tidak over-risk
    // Atau bisa juga Math.round(recommendedLotSize * 100) / 100; tergantung preferensi broker
    if (recommendedLotSize === 0) { // Pastikan lot minimal 0.01 jika memungkinkan
        recommendedLotSize = 0.01;
    }


    // --- Perhitungan Potensi Profit dan Nett SL (Risk Amount) ---
    // Nett SL adalah nilai uang yang akan hilang jika SL tercapai, berdasarkan lot yang disarankan
    const actualRiskAmount = recommendedLotSize * stopLossInPips * valuePerPointPerStandardLot;
    const potentialProfit = recommendedLotSize * tpPipsRaw / pipsPerUnit * valuePerPointPerStandardLot; // TP Pips raw selalu positif


    // --- Perhitungan Margin Required ---
    // Margin = (Contract Size * Lot Size * Open Price) / Leverage
    let marginRequired = (contractSize * recommendedLotSize * openPrice) / leverage;
    
    // Untuk JPY quoted pairs (USDJPY), harus dikalikan dengan nilai USD
    if (pairType === 'forex_jpy_quoted') {
        marginRequired = (contractSize * recommendedLotSize) / leverage; // Margin dalam USD (karena base currency USD)
    }


    // --- Tampilkan Hasil ---
    const resultsBody = document.getElementById('resultsBody');
    resultsBody.innerHTML = ''; // Hapus hasil sebelumnya
    document.getElementById('noResults').style.display = 'none'; // Sembunyikan pesan

    const row = resultsBody.insertRow();
    row.insertCell().textContent = symbols;
    row.insertCell().textContent = Math.round(slPips); // Bulatkan pips untuk tampilan
    row.insertCell().textContent = Math.round(tpPips); // Bulatkan pips untuk tampilan
    row.insertCell().textContent = recommendedLotSize.toFixed(2); // Format 2 desimal
    row.insertCell().textContent = `-$${actualRiskAmount.toFixed(2)}`; // Tampilkan sebagai negatif
    row.insertCell().textContent = `$${potentialProfit.toFixed(2)}`;
    row.insertCell().textContent = `$${marginRequired.toFixed(2)}`;

    // Highlight Nett SL (Risk Amount) dan Potensi Profit
    row.cells[4].style.color = '#dc3545'; // Merah
    row.cells[5].style.color = '#28a745'; // Hijau

    // Scroll ke bawah ke tabel hasil jika layar kecil
    resultsBody.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
